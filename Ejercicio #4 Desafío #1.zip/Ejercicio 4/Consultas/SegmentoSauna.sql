SELECT 
    Id, 
    'Ha ocupado Sauna' AS Servicio
FROM (
    SELECT Id, Sauna FROM SpaCentro
    UNION ALL
    SELECT Id, Sauna FROM SpaEscalon
    UNION ALL
    SELECT Id, Sauna FROM SpaSantaTecla
) AS Clientes
WHERE Sauna = 1;
