SELECT 
    Id, 
    'Ha ocupado Yoga' AS Servicio
FROM (
    SELECT Id, Yoga FROM SpaCentro
    UNION ALL
    SELECT Id, Yoga FROM SpaEscalon
    UNION ALL
    SELECT Id, Yoga FROM SpaSantaTecla
) AS Clientes
WHERE Yoga = 1;
