CREATE TABLE SpaCentro(
Id VARCHAR(100),
Sexo INT,
Ingresos DECIMAL (10,2),
PromVisit DECIMAL (5,2),
Edad INT,
Sauna INT,
Masaje INT,
Hidro INT,
Yoga INT
);

CREATE TABLE SpaEscalon(
Id VARCHAR(100),
Sexo INT,
Ingresos DECIMAL (10,2),
PromVisit DECIMAL (5,2),
Edad INT,
Sauna INT,
Masaje INT,
Hidro INT,
Yoga INT
);

CREATE TABLE SpaSantaTecla(
Id VARCHAR(100),
Sexo INT,
Ingresos DECIMAL (10,2),
PromVisit DECIMAL (5,2),
Edad INT,
Sauna INT,
Masaje INT,
Hidro INT,
Yoga INT
);