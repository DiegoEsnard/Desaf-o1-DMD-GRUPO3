SELECT 
    Id, 
    'Ha ocupado Masaje' AS Servicio
FROM (
    SELECT Id, Masaje FROM SpaCentro
    UNION ALL
    SELECT Id, Masaje FROM SpaEscalon
    UNION ALL
    SELECT Id, Masaje FROM SpaSantaTecla
) AS Clientes
WHERE Masaje = 1;
