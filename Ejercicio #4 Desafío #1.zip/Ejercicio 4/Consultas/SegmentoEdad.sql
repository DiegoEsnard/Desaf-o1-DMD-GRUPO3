SELECT 
    Id,
    CASE 
        WHEN Edad < 25 THEN 'J�venes'
        WHEN Edad BETWEEN 25 AND 45 THEN 'Adultos'
        ELSE 'Adultos Mayores'
    END AS GrupoEdad
FROM (
    SELECT Id, Edad FROM SpaCentro
    UNION ALL
    SELECT Id, Edad FROM SpaEscalon
    UNION ALL
    SELECT Id, Edad FROM SpaSantaTecla
) AS Clientes;
