SELECT 
    Id,
    CASE 
        WHEN Ingresos > 2000 AND PromVisit > 5 THEN 'Premium'
        WHEN Ingresos BETWEEN 1000 AND 2000 AND PromVisit BETWEEN 3 AND 5 THEN 'Regular'
        ELSE 'Ocasional'
    END AS SegmentoCliente,
    CASE 
        WHEN Edad < 25 THEN 'J�venes'
        WHEN Edad BETWEEN 25 AND 45 THEN 'Adultos'
        ELSE 'Adultos Mayores'
    END AS GrupoEdad
FROM (
    SELECT Id, Ingresos, PromVisit, Edad FROM SpaCentro
    UNION ALL
    SELECT Id, Ingresos, PromVisit, Edad FROM SpaEscalon
    UNION ALL
    SELECT Id, Ingresos, PromVisit, Edad FROM SpaSantaTecla
) AS Clientes;
