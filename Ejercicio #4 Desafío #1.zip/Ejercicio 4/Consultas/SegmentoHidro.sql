SELECT 
    Id, 
    'Ha ocupado Hidro' AS Servicio
FROM (
    SELECT Id, Hidro FROM SpaCentro
    UNION ALL
    SELECT Id, Hidro FROM SpaEscalon
    UNION ALL
    SELECT Id, Hidro FROM SpaSantaTecla
) AS Clientes
WHERE Hidro = 1;
