SELECT 
    Id,
    CASE 
        WHEN Ingresos > 2000 AND PromVisit > 5 THEN 'Premium'
        WHEN Ingresos BETWEEN 1000 AND 2000 AND PromVisit BETWEEN 3 AND 5 THEN 'Regular'
        ELSE 'Ocasional'
    END AS SegmentoCliente
FROM (
    SELECT Id, Ingresos, PromVisit FROM SpaCentro
    UNION ALL
    SELECT Id, Ingresos, PromVisit FROM SpaEscalon
    UNION ALL
    SELECT Id, Ingresos, PromVisit FROM SpaSantaTecla
) AS Clientes;
