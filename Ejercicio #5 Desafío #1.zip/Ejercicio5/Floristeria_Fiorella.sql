
WITH ProductosComprados AS (
    SELECT Departamento, 'Rosas' AS Producto, id
    FROM Ventas_Floristeria WHERE Rosas = 1
    UNION ALL
    SELECT Departamento, 'Claveles' AS Producto, id
    FROM Ventas_Floristeria WHERE Claveles = 1
    UNION ALL
    SELECT Departamento, 'Macetas' AS Producto, id
    FROM Ventas_Floristeria WHERE Macetas = 1
    UNION ALL
    SELECT Departamento, 'Tierra' AS Producto, id
    FROM Ventas_Floristeria WHERE Tierra = 1
    UNION ALL
    SELECT Departamento, 'Girasoles' AS Producto, id
    FROM Ventas_Floristeria WHERE Girasoles = 1
    UNION ALL
    SELECT Departamento, 'Hortensia' AS Producto, id
    FROM Ventas_Floristeria WHERE Hortensia = 1
    UNION ALL
    SELECT Departamento, 'Globos' AS Producto, id
    FROM Ventas_Floristeria WHERE Globos = 1
    UNION ALL
    SELECT Departamento, 'Tarjetas' AS Producto, id
    FROM Ventas_Floristeria WHERE Tarjetas = 1
    UNION ALL
    SELECT Departamento, 'Orqu�deas' AS Producto, id
    FROM Ventas_Floristeria WHERE Orqu�deas = 1
    UNION ALL
    SELECT Departamento, 'Carmes�' AS Producto, id
    FROM Ventas_Floristeria WHERE Carmes� = 1
    UNION ALL
    SELECT Departamento, 'Lirios' AS Producto, id
    FROM Ventas_Floristeria WHERE Lirios = 1
    UNION ALL
    SELECT Departamento, 'Aurora' AS Producto, id
    FROM Ventas_Floristeria WHERE Aurora = 1
    UNION ALL
    SELECT Departamento, 'Tulipanes' AS Producto, id
    FROM Ventas_Floristeria WHERE Tulipanes = 1
    UNION ALL
    SELECT Departamento, 'List�n' AS Producto, id
    FROM Ventas_Floristeria WHERE List�n = 1
)


INSERT INTO Combinaciones_Productos_Departamento (Departamento, Producto1, Producto2, VecesCompradasJuntas)
SELECT P1.Departamento, P1.Producto AS Producto1, P2.Producto AS Producto2, COUNT(*) AS VecesCompradasJuntas
FROM ProductosComprados P1
INNER JOIN ProductosComprados P2
    ON P1.id = P2.id  
    AND P1.Producto < P2.Producto  
GROUP BY P1.Departamento, P1.Producto, P2.Producto
ORDER BY VecesCompradasJuntas DESC;



WITH ProductosComprados AS (
    SELECT 'Rosas' AS Producto, id
    FROM Ventas_Floristeria WHERE Rosas = 1
    UNION ALL
    SELECT 'Claveles' AS Producto, id
    FROM Ventas_Floristeria WHERE Claveles = 1
    UNION ALL
    SELECT 'Macetas' AS Producto, id
    FROM Ventas_Floristeria WHERE Macetas = 1
    UNION ALL
    SELECT 'Tierra' AS Producto, id
    FROM Ventas_Floristeria WHERE Tierra = 1
    UNION ALL
    SELECT 'Girasoles' AS Producto, id
    FROM Ventas_Floristeria WHERE Girasoles = 1
    UNION ALL
    SELECT 'Hortensia' AS Producto, id
    FROM Ventas_Floristeria WHERE Hortensia = 1
    UNION ALL
    SELECT 'Globos' AS Producto, id
    FROM Ventas_Floristeria WHERE Globos = 1
    UNION ALL
    SELECT 'Tarjetas' AS Producto, id
    FROM Ventas_Floristeria WHERE Tarjetas = 1
    UNION ALL
    SELECT 'Orqu�deas' AS Producto, id
    FROM Ventas_Floristeria WHERE Orqu�deas = 1
    UNION ALL
    SELECT 'Carmes�' AS Producto, id
    FROM Ventas_Floristeria WHERE Carmes� = 1
    UNION ALL
    SELECT 'Lirios' AS Producto, id
    FROM Ventas_Floristeria WHERE Lirios = 1
    UNION ALL
    SELECT 'Aurora' AS Producto, id
    FROM Ventas_Floristeria WHERE Aurora = 1
    UNION ALL
    SELECT 'Tulipanes' AS Producto, id
    FROM Ventas_Floristeria WHERE Tulipanes = 1
    UNION ALL
    SELECT 'List�n' AS Producto, id
    FROM Ventas_Floristeria WHERE List�n = 1
)

INSERT INTO Combinaciones_Productos_Pais (Producto1, Producto2, VecesCompradasJuntas)
SELECT P1.Producto AS Producto1, P2.Producto AS Producto2, COUNT(*) AS VecesCompradasJuntas
FROM ProductosComprados P1
INNER JOIN ProductosComprados P2
    ON P1.id = P2.id  
    AND P1.Producto < P2.Producto  
GROUP BY P1.Producto, P2.Producto
ORDER BY VecesCompradasJuntas DESC;


TRUNCATE TABLE Combinaciones_Productos_Departamento;
TRUNCATE TABLE Combinaciones_Productos_Pais;
TRUNCATE TABLE Ventas_Departamento;                                                                                                                                                                                           
TRUNCATE TABLE Ventas_Pais;
TRUNCATE TABLE Ventas_Floristeria;
        
		




SELECT * FROM Ventas_Departamento;

SELECT * FROM Ventas_Pais;

SELECT * FROM Combinaciones_Productos_Departamento ORDER BY Departamento, VecesCompradasJuntas DESC;

SELECT * FROM Combinaciones_Productos_Pais ORDER BY VecesCompradasJuntas DESC;




